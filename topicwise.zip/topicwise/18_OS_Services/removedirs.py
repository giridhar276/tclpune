import os, sys

# listing directories
#print "The dir is: %s" %os.listdir(os.getcwd())

print ("The dir is: %s" %os.listdir("C:\\"))

# removing
#os.removedirs("/tutorialsdir")

# listing directories after removing directory
print ("The dir after removal is:" %os.listdir(os.getcwd()))
