x = [['1','2','3'],['4','5','6'],['7','8','9']]
print(x)

for val in x:
    print(val)


for ele in x:
    for val in ele:
        print(val)


