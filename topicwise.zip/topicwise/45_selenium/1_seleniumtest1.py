from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://www.linkedin.com/")

driver.find_element_by_tag_name
