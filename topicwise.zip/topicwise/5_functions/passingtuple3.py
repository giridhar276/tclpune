def tupleset(*p):
    print("Tuple values"  , p )
p = ( 10,20,30)
tupleset(*p)
