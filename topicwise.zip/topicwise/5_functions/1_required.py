#!/usr/bin/python

# example of required arguments
# function definition is here
def func(str1):
    # to print a passed string into function
    print(str1)
    

# Now you can call user defined function
 

func("Python programming")

