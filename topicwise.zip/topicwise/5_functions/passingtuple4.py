def tupleset(x,y,z):
    print(x,y,z)
p = ( 10,20,30)
tupleset(*p)
