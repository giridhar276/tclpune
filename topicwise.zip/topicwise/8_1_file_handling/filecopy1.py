
# copy the content from a input file to another file
f = open("demo.txt")
lines = f.readlines()
print(lines)
f.close()
f = open('demosample.txt', 'w')

f.close()


 
 

