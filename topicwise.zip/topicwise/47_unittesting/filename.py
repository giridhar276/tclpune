

print(__name__)
