import sys
for eachArg in sys.argv:
    print(eachArg)

print("All arguments :", sys.argv)

