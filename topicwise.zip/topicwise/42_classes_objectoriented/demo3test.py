
import demo5
print(demo5.__name__)

