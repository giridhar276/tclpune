#!/usr/bin/python

75 + vara*30 # (NameError: name 'vara' is not defined)
