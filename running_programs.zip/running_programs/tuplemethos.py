

# tuple methods
atup = (10,20,30)
print("Count of 10 is :",atup.count(10))

print("Index of the value is :", atup.index(30))