
# class definition
class Employee:
    def displayEmp(self):
        print("Inside displayEmp()")
    def displayAdd(self):
        print("Inside disppayAdd()")
        
#creating the object      
emp1 = Employee()
# calling the methods
emp1.displayEmp()
emp1.displayAdd()


emp2 = Employee()
emp2.displayAdd()
emp2.displayEmp
        
        
