

final = str(1) +  "hello"

print(final)