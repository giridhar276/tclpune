
#list
alist = [10,20,30]

alist[0] ="unix"

print("After modifying :", alist)


#tuple
atup = (10,20,30,430)
#   atup[0] = 10000

print("After modifying :", atup)