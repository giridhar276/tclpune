infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} ,2004:{"guj":90 }}


print("state literacy rate")
print("--------------------")

for key in infodoc:
    sub = infodoc[key]
    ikey = list(sub.keys())
    ival = list(sub.values())
    print(ikey[0].ljust(5),ival[0])
