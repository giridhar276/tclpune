


from netmiko import ConnectHandler
cisco = {

'device_type':'cisco_ios',
'ip':'127.0.0.1',
'port':5000,
'username':'cisco',
'password':'cisco',

}        
        
        
conn = ConnectHandler(**cisco)