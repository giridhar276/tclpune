


import os

# current directory
for file in os.listdir():
    print(file)
print("----------------------------")
#C:\\
path = "C:\\"    
for file in os.listdir(path):
    print(file)
    
    
    
