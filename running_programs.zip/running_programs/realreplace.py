

# replacing SACRAMENTO with PUNE

import urllib.request 
import sys

citylist = []
try:
    link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"    
    # to get the filename from the link
    filename = link.split("/")[-1]   #
    # downloading the file     
    urllib.request.urlretrieve(link,filename)        
    # reading the file
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line.replace("SACRAMENTO","PUNE"))

    ##### display the output ##########
    for city in set(citylist):
        print(city)
    
except Exception as err :
    print(err)    
    print(sys.exc_info()[0])
