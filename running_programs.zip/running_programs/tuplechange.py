

atup = (10,20,30)

print(atup)
# converting tuple to list
alist = list(atup)

alist[0] = "spark"
# reconvert back to tuple
atup = tuple(alist)

print(atup)
