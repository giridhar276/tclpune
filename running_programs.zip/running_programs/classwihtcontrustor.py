
########## with constructor ####################

class Employee:
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def displayName(self):
        print("Employee name :", self.name)
        print("Employee age  :", self.age)
        
#creating the object      
emp1 = Employee("Ram",30)
emp1.displayName()


emp2 = Employee("Rita",29)
emp2.displayName()

'''   *************** NOTES ****************

__init__(self) is called as contructor

Constructor is a builtin method which is invoked automatically without calling

Generally constructor is used to initialize the value

'''



