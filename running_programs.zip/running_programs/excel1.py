from openpyxl import Workbook
import time
wb = Workbook()

# grab the active worksheet
ws = wb.active

for val in range(1,10):
    ws.append([val])

# string with today's timestamp
filename = time.strftime("%d_%b_%Y.xlsx")
# Save the file
wb.save(filename)  