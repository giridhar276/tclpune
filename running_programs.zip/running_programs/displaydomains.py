
alist = ["google","oracle","microsoft"]

for domain in alist:
    host = "https://www." + domain + ".com"
    print(host)
    
    
    
alist = ["google","oracle","microsoft"]
for item in alist:
    if not item.startswith("www."):
        item = "www." + item
    if not item.endswith(".com"):
        item = item + ".com"  
    print(item)