'''
write a program to validate the IP address

Enter any IP address : 192.168.0.1
Its valid IP
Enter any IP address : 1001.1.2.3
Invalid IP
'''

# using functions and conditoins
# using re 


ip = input("Enter any ip address :")


out = ip.split(".")

if int(out[0]) in range(1,256)  and int(out[1]) in range(0,256) and  int(out[2]) in range(0,256)  and  int(out[3]) in range(1,256)    :
    print("Valid IP ")
else:
    print("Invalid IP")