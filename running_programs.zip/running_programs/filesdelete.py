# deleting files
import os
for file in os.listdir():
    if file.endswith(".csv"):
        os.unlink(file)   #or    os.remove(file)
