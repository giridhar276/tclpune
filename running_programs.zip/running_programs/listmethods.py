alist = [10,20,30,40,50]
alist.append(60)                   # adding one single object
print("After appending :", alist)
alist.append(70)
alist.append(80)
print("After appending :", alist)
alist.extend([34,643,34,4323,33232,1,10,10,10])
print("After extending :", alist)  # adding multiple values at a time
getcount = alist.count(10)
print("10 is repeated fo r :", getcount)
# alist.insert( where to insert , what to insert )
alist.insert(0,5)
print("After inserting :", alist)
alist.insert(4,35)
print("After inserting :", alist)
alist.pop()   # remove value at the last index
print("After pop :", alist)
alist.pop(1)  # remove value at the index 1
print("After pop :", alist)
# remove
alist.remove(20)    # remove the first occurence of 20
print("After remove :", alist)
alist.reverse()     # alist[::-1]
print("reverse of the list :", alist)
alist.sort()
print("Sorted output :", alist
      )