import getpass


#HOST = "127.0.0.1"
#port = 5000
#user = input("Enter your remote account: ")
#password = getpass.getpass("Enter password ")
#
#telnet = telnetlib.Telnet(HOST,port)
#
#telnet.read_until(b"Username:")
#telnet.write(user + "\n")
#
#telnet.read_until(b"Password:")
#telnet.write(password + "\n")
#

import telnetlib
bot = telnetlib.Telnet("127.0.0.1", 5000)
user = "cisco"
password = "cisco"
print("test")
bot.write((user + "\n").encode('ascii'))
print(bot.read_all())
print("test")
