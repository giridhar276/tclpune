adict = {"chap1":10 ,"chap2":20,"chap3":30}
print(adict.keys())     #display all th keys
print(adict.values())   # display all the values
print(adict.items())    # display all the items( list of tuples)
#print(adict["chap4"])
print(adict.get("chap4"))# will return None chap4 is not existing
print(adict.get("chap1"))#10
# adding new key-value pair
#adict[new key] = value
adict["chap5"] = 50
adict["chap6"] = 60
print("After adding new key-value pairs:", adict)

adict.setdefault("chap7")    # chap7-None will be added to the dictionary
print("After applying setdefault() :", adict) 
adict.setdefault("chap8",80) # chap8-80 will be added to the dictionary
print("After applying setdefault() :", adict) 
# remove key-value
adict.pop("chap1")      # chap1-10 will be removed
print("After pop  :", adict)

adict.popitem()         # will remove random key-value pair
print("After popitem :", adict)



