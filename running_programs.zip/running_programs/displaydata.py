
import pymysql

with pymysql.connect(host="localhost",port=3306, user ='root',password = 'india@123',database='tcl') as db:
    # will display connecting string if successful
    print(db)
    # query
    query = "select * from realestate"
    # executing the query
    db.execute(query)
    # displaying all the records
    for record in db.fetchall():
        print(record)

    # inserting record
    query = "insert into realestate values('{}','{}')".format('Kothrud','Pune')
    db.execute(query)

    # displaying the records
    query = "select * from realestate"
    # executing the query
    db.execute(query)
    # displaying all the records
    for record in db.fetchall():
        print(record)
    