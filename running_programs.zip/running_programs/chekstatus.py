
import requests

try:
    with open("links.txt")as fobj:
        for url in fobj:
            url= url.strip()
            response = requests.get(url)
            print(url.ljust(30) , response.status_code)
            
except requests.exceptions.ConnectTimeout :
    print("timeout error")