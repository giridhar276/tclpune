import socket


ip = '10.10.20.30'

if socket.inet_aton(ip):
    print("Valid IP")
else:
    print("Invalid IP")
    

try:
    ip = '10.10.20.300'

    if socket.inet_aton(ip):
        print("Valid IP")
    else:
        print("Invalid IP")

except Exception as error:
    print(error)
