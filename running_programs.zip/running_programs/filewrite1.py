
#open(C:\\Users\\gsripath\\Desktop\\a.txt","w")
#open("C:/Users/gsripath/Desktop/b.txt","w")

with open("numbers.txt","w")  as fobj:
    for val in range(1,100):
        fobj.write(str(val) + "\n")
        
        
# writing the set of ip's to the file
with open("numbers.txt","w")  as fobj:
    fixed = "192.168.0."
    for val in range(1,10):
        ip  = fixed + str(val)
        fobj.write(ip + "\n")
        
