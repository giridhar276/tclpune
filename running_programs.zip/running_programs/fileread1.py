try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)        
    output = 1  + "hello"

except FileNotFoundError :
    print("file not found")
except TypeError :
    print("Invalid operation")
except ValueError :
    print("Invalid input")
except Exception :      #-----------------------> base Exception
    print("Unknown error")
else:
    print("----------------------")