import os
fileslist = []
dirlist = []
for file in os.listdir():
    if os.path.isfile(file):
        fileslist.append(file)
    elif os.path.isdir(file):
        dirlist.append(file)
## display files first
print("************** FILES ***********")
for file in fileslist:
    print(file)
print("************** DIRECTORIES ***********")
## display dirs first
for file in dirlist:
    print(file)
