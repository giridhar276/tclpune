# display STREET and CITY ONLY 

import urllib.request 
import sys

citydict = dict()
try:
    link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"    
    # to get the filename from the link
    filename = link.split("/")[-1]   #
    # downloading the file     
    urllib.request.urlretrieve(link,filename)        
    # reading the file
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            output = line.split(",")
            # adding to dictionary
            citydict[output[1]] = 1
    ##### processing is done ##########
    ##### display the output ##########
    for city in citydict:
        print(city)
    
except Exception as err :
    print(err)    
    print(sys.exc_info()[0])
