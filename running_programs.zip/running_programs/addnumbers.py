


first= int(input("Enter first number :"))    #   '10'

second = int(input("Enter second number :")) #   '20'

output = first + second

print("sum of the numbers :", output)