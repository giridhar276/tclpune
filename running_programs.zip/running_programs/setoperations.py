alist = [10,20,30,40,50,10]
blist = [40,50,60,70,80]
aset = set(alist)
bset = set(blist)
print(aset.union(bset))   # UNIQUE of both a and b
print(aset.intersection(bset))

#write a program to check whether 'python' is existing in the string or not.
lang = "perl,unix,hadoop,scala,spark,ruby,go"
getcount = lang.count("python")
if getcount > 0 :
    print("Exists")
else:
    print("doesn't exist")
    
#method2
if "python" in lang:
    print("exists")
else:
    print("doesn't exist")