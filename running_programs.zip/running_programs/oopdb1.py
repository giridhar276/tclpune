
import pymysql


class Database:
    def __init__(self,host,port,user,password,database):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        
        
    def connectDB(self):
        self.db = pymysql.connect(self.host,self.port,self.user,self.password,self.database)
        return self.db 
            
            
    def displayData(self, query,string):
        self.query = query
        self.string = string
        cursor = self.string.cusror()
        cursor.execute(query)
        for record in cursor.fetchall():
            print(record)
    
            
db1 = Database("localhost",3306,'root','india@123','tcl')

string = db1.connectDB()
query = "select * from realestate"
db1.displayData(query,string)





