
# input()
name = input("Enter any name :")
print("You entered :", name)


# len()
print("length of the string :" , len(name))
# range()
print(list(range(1,10)))
# reverse order
print(list(range(10,1,-1)))
# check the type of object
print(type(1))
print(type([10,20,30]))
# validate the object
print(isinstance(10 , int))   # True
print(isinstance(10 , list))  # False

print(sum([10,20,30,40]))

print(min([10,20,30,40]))

# opening the file
fobj = open("test.txt","w")

