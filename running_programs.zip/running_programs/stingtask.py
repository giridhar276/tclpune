'''
capture any string from the keyboard and perform the below operations

1. check whether the string is upper or not
2. convert the string to list
3. display the string exactly in the center of 30 spaces width
4. convert the string into lower case
'''


name = input("Enter any string :")

if name.isupper():
    print("String is defined in upper case")
else:
    print("In lower case")


print("Converting string to list :")
print(list(name))

# display in center
print(name.center(30,'*'))

print(name.lower())

