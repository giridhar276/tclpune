

# REST API

import requests 

from bs4 import BeautifulSoup

domain = "https://www.tatacommunications.com/"

response = requests.get(domain)

print(response.status_code)  # will display the status code Eg 200


if response.status_code == 200 :    
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))

    
else:
    print("Invalid page")
