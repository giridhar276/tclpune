# Inheritence :   extracing of feature of one class in another class is known as
#                 Inheritence

# superclass or Parent class or Base class


class Parent:    
    def displayName(self):
        print("this is parent()")
        
# subclass or Child class or derived class        
class Child(Parent):
    def displayAge(self):
        print("tihs is child()")
        
        
obj1 = Child()

obj1.displayName()

obj1.displayAge()