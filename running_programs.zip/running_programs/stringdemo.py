
name = "python programming"
# string[start:stop:step]
print(name[0])  #p
print(name[1])  #y
print(name[0:10]) #python pro
print(name[::])   # everything
print(name[:])    # everything
print(name[2:6])  #thon 
print(name[0:16:2])
print(name[1:16:2])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])    # reverse of the string
















