name = "python programming"
print(name)
print(name.upper())
print(name.lower())
print(name.isupper())
getcount = name.count("p")
print("Count of p :", getcount)
print(name.center(30))
print(name.center(30,"*"))
print(name.isalpha())
print(name.capitalize())
aname = "  python  "
print(aname.strip())  # will remove space at both the ends
print(aname.lstrip()) #remove space at left side
print(name.split(" ")) # converting to list [python,programming]
bname = "I love {} and {}"
print(bname.format("unix","java"))
print(bname.format("spark","cloud"))

print("unix","java")
print("unix".ljust(10), "java")
print(name.replace(" ",""))    # str.replace(source,des)
print(name.replace("python","ruby"))  # ruby programming

