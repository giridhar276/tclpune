
#  reading line by line

with open("numbers.txt","r") as fobj:
    for line in fobj:
        # will remove white spaces at the end of the string
        line = line.strip()
        print(line)

print("------------")
# using read() : reading the complete file in string format
with open("numbers.txt","r") as fobj:
    print(fobj.read())



# using readlines() : reading the file in list format
with open("numbers.txt","r") as fobj:
    print(fobj.readlines())
