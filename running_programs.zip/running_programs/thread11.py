import threading

def worker(num):
    """thread worker function"""
    print('Worker: %s' % num)
    return

threads = []
for i in [11,22,33,44,55,66,77,88,99]:
    t = threading.Thread(target=worker, args=(i,))
    threads.append(t)
    t.start()