

class Parent:
    def __init__(self):
        print("this is parent class constructor")
    def displayName(self):
        print("this is parent()")
        
# subclass or Child class or derived class        
class Child(Parent):
    def __init__(self):
        print("this is child class constructor")
        # super() is used to invoke parent class constructor
        super().__init__()
    def displayAge(self):
        print("tihs is child()")
        
        
obj1 = Child()

obj1.displayName()

obj1.displayAge()
