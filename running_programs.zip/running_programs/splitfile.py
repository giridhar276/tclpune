#write a program to capture any filename from the keyboard and display its filename and extension seperately
filename = input("Enter anu filename :")
data = filename.split(".")
print("File name :", data[0])
print("Extension :", data[1])


#write  a program to capture some delimeted string from the keyboard and split the string with comma and display the length after splitting.
string = input("Enter any delimeted string :")
out = string.split(",")
print("List elements are :", out)
print("Length of list    :", len(out))

#3