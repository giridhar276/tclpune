
import re
with open("languages.txt") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt*hon programming" ,line):
            print(line)