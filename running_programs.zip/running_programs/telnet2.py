import telnetlib
bot = telnetlib.Telnet("127.0.0.1", 22)
user = "dobbs"
bot.write((user + "\n").encode('ascii'))
print(bot.read_all())