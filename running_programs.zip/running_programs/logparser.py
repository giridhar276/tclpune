from threading import Thread
import time

def collect_logs(log_directory):
    global threads
    if os.path.exists(log_directory):
        pass
    else:
        return 1

    # change the time to 30 mins once deployed
    args = log_directory + " " + "-type f -cmin -180"
    cmd = "/usr/bin/find" + " " + args

    opf = open(output_file, 'w')
    opf.write('')
    opf.close()

    p = subprocess.Popen([cmd], stdout = subprocess.PIPE , stderr = subprocess.STDOUT, shell=True)
    out, err = p.communicate()

    out = list(filter(lambda x: x is not '', out.split('\n')))
    threads = []
    print out

    for f in out:
        t = Thread(target=process_file, args=(f,))
        threads.append(t)

        if len(threads) < 5 and out.index(f) != len(out)-1:
            continue

        run_threads()
        #print "#"*80
        threads = []


def process_file(fname):
    global output_file
    with open(fname, 'r') as fd:
        for line in fd.readlines():
            matchObj = re.match(r'.*Exception.*|.* error .*|.*constraint.*|.*Foreign key.*|.*could not resolve.*|.*ora-.*', line, re.I)
            if matchObj:
                with open(output_file, 'a') as op:
                    err_string = fname + ' ==> ' + matchObj.group() + '\n'
                    op.write(err_string)


def run_threads():
    global threads
    for t in threads:
        t.start()

    for t in threads:
        t.join()


if __name__ == "__main__" :
    log_locations = ["/u01/.project/atpd_metrics/logs"]

    if os.path.exists("/u01/scripts/properties.config"):
        readparser = ConfigParser()
        readparser.read('/u01/scripts/' + 'properties.config')
        log_directory = readparser.get('database_config', 'log_directory')
        log_locations.append(log_directory)

    output_file = "/tmp/atpd_metrics_log_errors.txt"
    threads = []

    #for ldir in [log_directory, "/u01/.project/atpd_metrics/logs"]:
    for ldir in log_locations:
        collect_logs(ldir)


    recipients = "abc@gmail.com"

    mail_cmd =  "mail -v -s 'ATP-D Metrics - Log error report[US-Ashburn]' -r 'abc@gmail.com' -S replyto='abc@gmail.com' -S smtp='smtp.us-ashburn-1.awscloud.com:25' -S smtp-use-starttls -S smtp-auth=plain -S smtp-auth-user='ocid1.user.oc1..aaaaaaaa53dmuxnijbomncdbj5cudtwk2nuluwtf5kx5aizycbwddogmtjea@ocid1.tenancy.oc1..aaaaaaaahg77sehzz7yblywheprxs6xw7vzv6q3n4fv3hm5bctyf3im64tlq.fe.com' -S smtp-auth-password='vakqF44p{DXDSWRkWJ.j' -S ssl-verify=ignore  -S nss-config-dir='/etc/pki/nssdb'" + " " + recipients

    if os.stat(output_file).st_size == 0:
        #mail_header = "***No errors found***"
        #cmd = "echo " + mail_header + ' |' + mail_cmd
        print time.strftime("%m/%d/%Y %H:%M:%S") + " - " + "No errors found"
    else:
        #mail_header = ""
        cmd = mail_cmd + '<' + output_file
        p = subprocess.Popen([cmd], stdout = subprocess.PIPE , stderr = subprocess.STDOUT, shell=True)
        out, err = p.communicate()
        print out
        print err

