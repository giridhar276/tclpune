# for with range
for val in range(1,11):
    print(val)

# for with string
for char in "python":
    print(char)

# for with list
alist = [10,20,30,40]
for val in alist:
    print(val)

# for with tuple
for val in (10,20,30,40,50):
    print(val)

# for with dictionary
adict = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key in adict:
    print(key)          # chap1
    print(adict[key])   #10

# for with set
aset = {10,10,10,10,10,10}
for val in aset:
    print(val)
