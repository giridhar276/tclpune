import sys
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
    output = 1 +  "hello"
except FileNotFoundError as err:
    print("file not found")
    print("System defined error :", err)
    print(sys.exc_info()[0])
except TypeError as err:
    print("Invalid operation")
    print("System defined error :", err)
    print(sys.exc_info()[0])
except ValueError as err:
    print("Invalid input")
    print("System defined error :", err)
    print(sys.exc_info()[0])
except Exception as err:      
    print("Unknown error")
    print("System defined error :", err)
    print(sys.exc_info()[0])
else:
    print("----------------------")
