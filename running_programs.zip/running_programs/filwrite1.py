
# write operation   # method1
# opening the file
fobj = open("clients.txt","w")
# writing the output to the file
fobj.write("python programming\n")
fobj.write("unix shell\n")
# closing the file
fobj.close()


# using context manager   :  file will be closed automatically when it it out of indentation
#2nd method
with open("info.txt","w") as fobj:
    fobj.write("scala programming\n")
    fobj.write("spark tool\n")
        
