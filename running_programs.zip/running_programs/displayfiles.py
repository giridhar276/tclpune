# list files of local path
import os

for file in os.listdir():
    print(file)
    
print("-----------------------------------")
# list files of C:
import os
path ="C:\\"
for file in os.listdir(path):
    print(file)
    
print("-----------------------------------")
# same using glob
import glob
for file in glob.glob("C:\\Users\\gsripath\\Desktop\\programs\\*.py"):
    print(file)
    

# file and its size
import os    
for file in os.listdir():
    getsize= os.path.getsize(file)
    print(file.ljust(40) , getsize ,"bytes")    