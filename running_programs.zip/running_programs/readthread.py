import requests
import threading


def displayStatus(url):
    response = requests.get(url)
    print(url.ljust(20), response.status_code)


with open("links.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        thread1 = threading.Thread(target = displayStatus,args = (line,))
        thread1.start()


