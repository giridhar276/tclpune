
#### without constructor ###########

class Employee:
    def getData(self,name,age):
        self.name = name
        self.age = age

    def displayName(self):
        print("Employee name :", self.name)
        print("Employee age  :", self.age)
        
#creating the object      
emp1 = Employee()
emp1.getData("Ram",30)
emp1.displayName()


emp2 = Employee()
emp2.getData("Rita",29)
emp2.displayName()
