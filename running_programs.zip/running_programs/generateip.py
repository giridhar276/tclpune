'''
write a program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''

for item in range(1,11):
    fixed = "192.168.0."
    ip = fixed + str(item)
    print(ip)


'''
192.168.0.1
192.168.0.2
192.168.0.3
..
192.168.1.10
'''

for val in range(0,2):
    fixed = "192.168." + str(val)
    for val in range(1,11):
        ip = fixed + "." + str(val)
        print(ip)




