from openpyxl import Workbook
import os

wb = Workbook()

# grab the active worksheet
ws = wb.active

for file in os.listdir():
    ws.append([file])

# Save the file
wb.save("listoffiles.xlsx")



