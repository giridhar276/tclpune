#3write a program to read the realestate.csv file and display all the lines from the file

import urllib.request 
import sys
try:
    link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"    
    # to get the filename from the link
    filename = link.split("/")[-1]   #
    # downloading the file     
    urllib.request.urlretrieve(link,filename)        
    # reading the file
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except Exception as err :
    print(err)    
    print(sys.exc_info()[0])