# import openpyxl module 
import openpyxl 
  
# Give the location of the file 
path = "demo.xlsx"
  
# to open the workbook  
# workbook object is created 
wb_obj = openpyxl.load_workbook(path) 
sheet_obj = wb_obj.active 
  
# print the total number of rows 
maxrow = sheet_obj.max_row


for rowval in range(1,maxrow):      
    cell_obj = sheet_obj.cell(row = rowval, column = 1)   
    print(cell_obj.value)