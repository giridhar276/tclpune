# import openpyxl module 
########## READING ONLY 1 CELL ( 1st row 1st col)
import openpyxl 
path = "realestate.xlsx"
wb_obj = openpyxl.load_workbook(path) 
sheet_obj = wb_obj.active     
cell_obj = sheet_obj.cell(row = 1, column = 1)   
print(cell_obj.value)


# row count

# displaying the max row that is available
import openpyxl   
# Give the location of the file 
path = "realestate.xlsx"  
# workbook object is created 
wb_obj = openpyxl.load_workbook(path)   
sheet_obj = wb_obj.active   
# ptint total number of column  
print(sheet_obj.max_row)