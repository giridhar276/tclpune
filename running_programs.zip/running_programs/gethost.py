import socket
hostname = socket.gethostname()    # will display hostname
print("HOSTname :",hostname )      # will display IP from hostname


print("IP Address :", socket.gethostbyname(hostname))


import os
print(os.name)         #  os name
print(os.getlogin())   # display name   # Linux  whoami

print(os.getcwd())    # display the current working directory


import sys
print(sys.version)            # verion of python
print(sys.version_info)        # verion of python

print(sys.builtin_module_names)  # all the builtin libraries

print(sys.modules)        # all the third party modules

print(sys.executable)     # path of python executable