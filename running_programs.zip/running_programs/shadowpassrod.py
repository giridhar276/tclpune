

import getpass


password= getpass.getpass("Enter password :")

print("Your password :", password)


print("***********   Using stdiomask *************")
import stdiomask

password = stdiomask.getpass("Enter password :")
print("Your password :", password)


