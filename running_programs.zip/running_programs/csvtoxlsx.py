### converting from   csv -----> excel
from openpyxl import Workbook
import os
import csv

wb = Workbook()

# grab the active worksheet
ws = wb.active

with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        ws.append(line)
        
# Save the file
wb.save("realestateexcel.xlsx")

