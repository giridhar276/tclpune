

# list 
alist = [10,20,30,40,50,60]
print(alist)

print(alist[0])
print(alist[1])
print(alist[0:10])
print(alist[::])
print(alist[:])
print(alist[2:6])
print(alist[0:6:2])
print(alist[-4:-1])
print(alist[::-1])   # list reverse
      
