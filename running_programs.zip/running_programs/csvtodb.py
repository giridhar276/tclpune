
import pymysql
import csv

with pymysql.connect(host="localhost",port=3306, user ='root',password = 'india@123',database='tcl') as db:
    # will display connecting string if successful
    print(db)
    
    with open("realestate.csv") as fobj:
        # creating the csv object
        reader = csv.reader(fobj)
        for line in reader:
            #print(line)
            query = "insert into realestateinfo values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(*line)
            db.execute(query)
            print(db.rowcount , "record inserted")
            
            
    
    