# if condition
a,b = 10,20
if a < b:
    print("INside if")
    print("A is less than B")
    
name = "python"
if name.isupper():
    print("String is upper")
    
# if-else
name = "python"
if name.isupper():
    print("String is upper")
else:
    print("String is lower")

# if-elif-elif-elif-elif- ....else
color = input("Enter any color:")
if color == "red":
    print("Color is redd")
elif color =="blue":
    print("Color is blue")
elif color == "black":
    print("color is black")
else :
    print("Uknown color")    