
# set methods

aset = {10,10,10,20,30,40}
bset = {30,40,50}

print(aset)
print(bset)

print(aset.union(bset))
print(aset.intersection(bset))
print(aset.difference(bset))

